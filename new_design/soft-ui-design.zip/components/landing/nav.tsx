"use client"

import Link from "next/link"

export function Nav() {
  return (
    <nav className="pointer-events-none fixed inset-x-0 top-0 z-50 flex items-center justify-between px-6 py-5 lg:px-12">
      {/* Logo */}
      <Link
        href="/"
        className="pointer-events-auto flex items-center gap-2 text-teal"
      >
        <svg
          width="28"
          height="28"
          viewBox="0 0 28 28"
          fill="none"
          aria-hidden="true"
        >
          <circle cx="14" cy="14" r="12" stroke="currentColor" strokeWidth="2" />
          <circle cx="14" cy="14" r="4" fill="hsl(22 85% 49%)" />
        </svg>
        <span className="font-display text-lg font-bold tracking-tight">
          PetCheck
        </span>
      </Link>

      {/* Language switcher */}
      <button
        type="button"
        className="pointer-events-auto rounded-full border border-border bg-card/80 px-3 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur-sm transition-colors hover:bg-card hover:text-foreground"
      >
        UA / EN
      </button>
    </nav>
  )
}
