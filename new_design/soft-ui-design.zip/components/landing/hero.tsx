"use client"

import Link from "next/link"

export function Hero() {
  return (
    <section className="relative flex min-h-screen flex-col lg:flex-row">
      {/* Left 5 cols — text + CTA */}
      <div className="relative z-10 flex flex-1 flex-col justify-center px-6 pb-12 pt-24 lg:max-w-[42%] lg:px-12 lg:py-0">
        <div className="max-w-lg">
          {/* Badge */}
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-sage px-3 py-1">
            <span className="h-1.5 w-1.5 rounded-full bg-coral" />
            <span className="text-xs font-medium text-sage-deep">Beta</span>
          </div>

          <h1 className="font-display text-4xl font-bold leading-[1.1] tracking-tight text-teal lg:text-6xl xl:text-7xl">
            <span className="text-balance">
              {"Know what\u2019s safe"}
              <br />
              {"for your pet"}
              <span className="text-coral">.</span>
            </span>
          </h1>

          <p className="mt-6 max-w-sm text-base leading-relaxed text-muted-foreground lg:text-lg">
            {"Medical-grade food safety analysis. Check any product\u2019s composition or verify ingredient toxicity \u2014 in seconds."}
          </p>

          {/* CTA buttons — staircase layout */}
          <div className="mt-12 flex flex-col gap-3 sm:max-w-xs">
            <Link
              href="/diet-validator"
              className="group flex h-14 items-center justify-center rounded-xl bg-teal px-8 text-base font-semibold text-primary-foreground transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <span className="flex items-center gap-3">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                  <path d="M10 2v16M2 10h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
                {"Analyse Composition"}
              </span>
            </Link>
            <Link
              href="/safety-check"
              className="group ml-0 flex h-14 items-center justify-center rounded-xl border-2 border-teal bg-transparent px-8 text-base font-semibold text-teal transition-all hover:bg-teal hover:text-primary-foreground active:scale-[0.98] sm:ml-10"
            >
              <span className="flex items-center gap-3">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                  <path d="M10 2l6 3v5c0 4-3 7-6 8-3-1-6-4-6-8V5l6-3z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
                </svg>
                {"Check Toxicity"}
              </span>
            </Link>
          </div>
        </div>
      </div>

      {/* Right 7 cols — visual bleed */}
      <div className="relative flex-1 overflow-hidden bg-sage lg:min-h-screen">
        {/* Abstract geometric shapes for visual interest */}
        <div className="absolute inset-0 flex items-center justify-center">
          {/* Large teal circle */}
          <div className="absolute right-[10%] bottom-[15%] h-64 w-64 rounded-full border-2 border-teal/10 lg:h-96 lg:w-96" />
          {/* Coral dot */}
          <div className="absolute right-[25%] top-[30%] h-6 w-6 rounded-full bg-coral/20 lg:h-10 lg:w-10" />
          {/* Small teal circle */}
          <div className="absolute left-[15%] top-[45%] h-20 w-20 rounded-full bg-teal/5 lg:h-32 lg:w-32" />

          {/* Central icon composition */}
          <div className="relative flex flex-col items-center gap-6">
            {/* Paw print */}
            <svg
              width="120"
              height="120"
              viewBox="0 0 120 120"
              fill="none"
              className="text-teal/15 lg:h-[200px] lg:w-[200px]"
              aria-hidden="true"
            >
              <ellipse cx="42" cy="32" rx="12" ry="14" fill="currentColor" />
              <ellipse cx="78" cy="32" rx="12" ry="14" fill="currentColor" />
              <ellipse cx="28" cy="58" rx="10" ry="12" fill="currentColor" />
              <ellipse cx="92" cy="58" rx="10" ry="12" fill="currentColor" />
              <ellipse cx="60" cy="78" rx="22" ry="20" fill="currentColor" />
            </svg>

            {/* Shield with check */}
            <svg
              width="48"
              height="48"
              viewBox="0 0 48 48"
              fill="none"
              className="text-coral/30 lg:h-16 lg:w-16"
              aria-hidden="true"
            >
              <path
                d="M24 4l16 6v10c0 10-7 18-16 22C15 38 8 30 8 20V10l16-6z"
                stroke="currentColor"
                strokeWidth="2"
              />
              <path
                d="M16 24l6 6 10-12"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </div>
        </div>

        {/* Mobile: Top 40%, Desktop: 100% height bleed */}
        <div className="h-[40vh] lg:h-full" />
      </div>
    </section>
  )
}
