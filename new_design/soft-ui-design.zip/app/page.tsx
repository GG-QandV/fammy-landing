import { Nav } from "@/components/landing/nav"
import { Hero } from "@/components/landing/hero"
import { FeatureCards } from "@/components/landing/feature-cards"
import { MiniFounder } from "@/components/landing/mini-founder"
import { Footer } from "@/components/landing/footer"

export default function Page() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <FeatureCards />
        <MiniFounder />
      </main>
      <Footer />
    </>
  )
}
